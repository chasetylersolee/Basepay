// Simple interactivity for the demo
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

const menuBtn = document.querySelector('.menu-toggle');
const navLinks = document.getElementById('nav-links');
if (menuBtn && navLinks) {
  menuBtn.addEventListener('click', () => {
    const open = navLinks.classList.toggle('open');
    menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}

window.demoPreview = (e) => {
  const file = e.target.files[0];
  const result = document.getElementById('fileResult');
  if (!file) { result.textContent = ''; return; }
  const max = 4 * 1024 * 1024;
  if (file.size > max) {
    result.textContent = 'File is large. For beta, limit ~4MB.';
    return;
  }
  result.textContent = `Selected: ${file.name} (${Math.round(file.size/1024)} KB)`;
};

window.fakePlan = () => {
  const plan = document.getElementById('plan');
  if (!plan) return;
  plan.textContent = 'This payday: +1% TSP ($30), $150 to emergency fund, $75 to auto loan.';
};

window.fakeSubmit = () => {
  const email = document.getElementById('email');
  const thanks = document.getElementById('thanks');
  if (!email || !thanks) return;
  if (!email.value || !email.checkValidity()) {
    thanks.textContent = 'Please enter a valid email.';
    return;
  }
  thanks.textContent = 'Thanks! We’ll email you an invite when the beta opens.';
};
